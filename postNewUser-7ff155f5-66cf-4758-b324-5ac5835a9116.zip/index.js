const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler = async (event, context, callback) => {
    // Captures the requestId from the context message


    // Handle promise fulfilled/rejected states
    await createUser(event).then(() => {
        callback(null, {
            statusCode: 201,
            body: '',
            headers: {
                'Access-Control-Allow-Origin' : '*'
            }
        });
    }).catch((err) => {
        console.error(err)
    })
};

// Function createMessage
// Writes message to DynamoDb table Message 
function createUser(user) {
    const params = {
        TableName: 'Users',
        Item: {
            'userId' : user.userId,
            'photo': user.photo!=null? user.photo:'https://www.hrlact.org/wp-content/uploads/2020/12/generic-user-icon.jpg'
        }
    }
    return dynamo.put(params).promise();
}
