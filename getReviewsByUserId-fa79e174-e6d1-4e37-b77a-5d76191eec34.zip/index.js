const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler = async (event, context, callback) => {
    // Handle promise fulfilled/rejected states
    await getReviews(event.userId).then(data => {
        callback(null, {
            // If success return 200, and items
            statusCode: 200,
            body: data.Items,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
        })
    }).catch((err) => {
        // If an error occurs write to the console
        console.error(err);
    })
};


function getReviews(userId) {
    const params = {
        TableName: 'Reviews',
        FilterExpression:
            "attribute_not_exists(deletedAt) AND contains(userId, :userId)",
        ExpressionAttributeValues: {
            ":userId": userId,
        },
        Limit: 10
    }
    return dynamo.scan(params).promise();
}
