const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler = async (event, context, callback) => {
    // Handle promise fulfilled/rejected states
    await getUser(event.userId).then(data => {
        callback(null, {
            // If success return 200, and items
            statusCode: 200,
            body: data.Item,
            headers: {
                'Access-Control-Allow-Origin': '*',
            },
        })
    }).catch((err) => {
        // If an error occurs write to the console
        console.error(err);
    })
};


function getUser(userId) {
    const params = {
        TableName: 'Users',
        Key:{
            userId: userId
        }
    }
    return dynamo.get(params).promise();
}
