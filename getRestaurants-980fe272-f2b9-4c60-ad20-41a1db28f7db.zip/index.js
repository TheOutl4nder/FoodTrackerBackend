const axios = require('axios');
const AWS = require('aws-sdk'), region='us-east-1',secretName='Google-API-Key';

const client = new AWS.SecretsManager({
    region:region
});

const get_secret= async(SecretId)=>{
    return await new Promise((resolve, reject)=>{
        client.getSecretValue({SecretId},(err,result)=>{
            if(err) reject(err)
            else resolve(JSON.parse(result.SecretString))
        })
    })
}

exports.handler = async (event,context,callback) => {
    const { APIKEY } = await get_secret(secretName);
    
    var config = {
      method: 'get',
      url: `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${event.restaurantQuery}%20in%20Guadalajara&type=restaurant&key=${APIKEY}`,
      headers: {
        "Access-Control-Allow-Origin" : "*", // Required for CORS support to work
        "Access-Control-Allow-Credentials" : true, // Required for cookies, authorization headers with HTTPS
        "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
        }
    };
    let reply ={};
    
    await axios(config)
    .then(function (response) {
        reply = {
            statusCode: 200,
            headers: { 
                "Access-Control-Allow-Headers" : "Content-Type", 
                "Access-Control-Allow-Origin": "*", 
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET" 
            },
            body: response.data,
        };
    })
    .catch(function (error) {
        console.log("Valió");
        reply = {
            statusCode: 400,
            headers: { 
                "Access-Control-Allow-Headers" : "Content-Type", 
                "Access-Control-Allow-Origin": "*", 
                "Access-Control-Allow-Methods": "OPTIONS,POST,GET" 
            },
        };
    });
    return reply;
};

