const AWS = require('aws-sdk');
const dynamo = new AWS.DynamoDB.DocumentClient({region:'us-east-1'});

exports.handler = async (event, context, callback) => {
    // Captures the requestId from the context message
    // Handle promise fulfilled/rejected states
    await createDish(event).then(() => {
        callback(null, {
            statusCode: 201,
            body: '',
            headers: {
                'Access-Control-Allow-Origin' : '*'
            }
        });
    }).catch((err) => {
        console.error(err)
    })
};

// Function createMessage
// Writes message to DynamoDb table Message 
function createDish(dish) {
    const params = {
        TableName: 'Dishes',
        Item: {
            'dishId' : dish.dishId,
            'category': dish.category,
            'description': dish.desc,
            'name': dish.name,
            'restaurantId' : dish.restaurantId,
            'restaurantName': dish.restaurantName,
            'image':dish.image
        }
    }
    return dynamo.put(params).promise();
}
